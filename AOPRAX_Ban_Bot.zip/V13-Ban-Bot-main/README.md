## Kurulum
Terminale ```npm i```
yazıp modüllerin indirilmesini bekleyin. 
<br>
<br> 
modüller indirildikten sonra```npm start``` yazınız.

## Ayarlar
Botun yapılması gerek tüm ayarlarını `src/bash/settings.json` dosyasından yapabilirsiniz.
<br>
Discord sunucumuz'a katılmayı ve projeye star atmayı unutmayın 👋

## İletişim

[Kod paylaşım sitemiz](https://covid-19code.xyz/) <br>
[Discord Sunucumuz](https://discord.gg/mztsyWR3QU) <br>
[Bana ulaşmak için](https://discord.com/users/673210759274299413) <br>

## Önemli Not

Sunucu patlatma botları, discord tos'da yasaklanan bir bot türüdür. Botu kullandığınız süre boyunca discord tarafından yaptırıma maruz kalma şansınız vardır, olası bir yasaklama veya yasal bir durumda Covid-19 Code herhangi bir sorumluluk kabul etmez ve tüm riskler kullanıcıya aittir.

## Lisans

Altyapı tamamen Covid-19 Codeye ayittir ve izinsiz paylaşılması kesinlikle yasaktır.
